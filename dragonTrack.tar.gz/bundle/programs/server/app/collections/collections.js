(function(){
Students = new Meteor.Collection('students');
Incidents = new Meteor.Collection('incidents');
HousePoints = new Meteor.Collection('housePoints');
ChatMessages = new Meteor.Collection('chatMessages');
systemVariables = new Meteor.Collection('systemVariables');
Votes = new Meteor.Collection('votes');

Currency = new Meteor.Collection('kkwai');

}).call(this);

//# sourceMappingURL=collections.js.map
