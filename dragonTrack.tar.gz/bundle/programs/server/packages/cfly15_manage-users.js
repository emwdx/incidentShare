(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Roles = Package['alanning:roles'].Roles;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var filteredUserQuery, users, obj, ManageUsers;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// packages/cfly15_manage-users/packages/cfly15_manage-users.js                        //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
(function () {                                                                         // 1
                                                                                       // 2
//////////////////////////////////////////////////////////////////////////////////     // 3
//                                                                              //     // 4
// packages/cfly15:manage-users/libs/user_query.js                              //     // 5
//                                                                              //     // 6
//////////////////////////////////////////////////////////////////////////////////     // 7
                                                                                //     // 8
filteredUserQuery = function(userId, filter) {                                  // 1   // 9
	// if not an admin user don't show any other user                              // 2   // 10
	if (!Roles.userIsInRole(userId, ['admin']))                                    // 3   // 11
		return Meteor.users.find(userId);                                             // 4   // 12
                                                                                // 5   // 13
	// TODO: configurable limit and paginiation                                    // 6   // 14
	var queryLimit = 25;                                                           // 7   // 15
                                                                                // 8   // 16
	if(!!filter) {                                                                 // 9   // 17
		// TODO: passing to regex directly could be dangerous                         // 10  // 18
		users = Meteor.users.find({                                                   // 11  // 19
			$or: [                                                                       // 12  // 20
				{'profile.name': {$regex: filter, $options: 'i'}},                          // 13  // 21
				{'emails.address': {$regex: filter, $options: 'i'}}                         // 14  // 22
			]                                                                            // 15  // 23
		}, {sort: {emails: 1}, limit: queryLimit});                                   // 16  // 24
	} else {                                                                       // 17  // 25
		users = Meteor.users.find({}, {sort: {emails: 1}, limit: queryLimit});        // 18  // 26
	}                                                                              // 19  // 27
	return users;                                                                  // 20  // 28
};                                                                              // 21  // 29
                                                                                // 22  // 30
//////////////////////////////////////////////////////////////////////////////////     // 31
                                                                                       // 32
}).call(this);                                                                         // 33
                                                                                       // 34
                                                                                       // 35
                                                                                       // 36
                                                                                       // 37
                                                                                       // 38
                                                                                       // 39
(function () {                                                                         // 40
                                                                                       // 41
//////////////////////////////////////////////////////////////////////////////////     // 42
//                                                                              //     // 43
// packages/cfly15:manage-users/server/startup.js                               //     // 44
//                                                                              //     // 45
//////////////////////////////////////////////////////////////////////////////////     // 46
                                                                                //     // 47
Meteor.startup(function() {                                                     // 1   // 48
	// create an admin role if it doesn't exist                                    // 2   // 49
	if (Meteor.roles.find({name: 'admin'}).count() < 1 ) {                         // 3   // 50
		Roles.createRole('admin');                                                    // 4   // 51
	}                                                                              // 5   // 52
});                                                                             // 6   // 53
//////////////////////////////////////////////////////////////////////////////////     // 54
                                                                                       // 55
}).call(this);                                                                         // 56
                                                                                       // 57
                                                                                       // 58
                                                                                       // 59
                                                                                       // 60
                                                                                       // 61
                                                                                       // 62
(function () {                                                                         // 63
                                                                                       // 64
//////////////////////////////////////////////////////////////////////////////////     // 65
//                                                                              //     // 66
// packages/cfly15:manage-users/server/publish.js                               //     // 67
//                                                                              //     // 68
//////////////////////////////////////////////////////////////////////////////////     // 69
                                                                                //     // 70
Meteor.publish('roles', function (){                                            // 1   // 71
	return Meteor.roles.find({});                                                  // 2   // 72
});                                                                             // 3   // 73
                                                                                // 4   // 74
Meteor.publish('filteredUsers', function(filter) {                              // 5   // 75
	return filteredUserQuery(this.userId, filter);                                 // 6   // 76
});                                                                             // 7   // 77
//////////////////////////////////////////////////////////////////////////////////     // 78
                                                                                       // 79
}).call(this);                                                                         // 80
                                                                                       // 81
                                                                                       // 82
                                                                                       // 83
                                                                                       // 84
                                                                                       // 85
                                                                                       // 86
(function () {                                                                         // 87
                                                                                       // 88
//////////////////////////////////////////////////////////////////////////////////     // 89
//                                                                              //     // 90
// packages/cfly15:manage-users/server/methods.js                               //     // 91
//                                                                              //     // 92
//////////////////////////////////////////////////////////////////////////////////     // 93
                                                                                //     // 94
Meteor.methods({                                                                // 1   // 95
	deleteUser: function(userId) {                                                 // 2   // 96
		var user = Meteor.user();                                                     // 3   // 97
		if (!user || !Roles.userIsInRole(user, ['admin']))                            // 4   // 98
			throw new Meteor.Error(401, "You need to be an admin to delete a user.");    // 5   // 99
                                                                                // 6   // 100
		if (user._id == userId)                                                       // 7   // 101
			throw new Meteor.Error(422, 'You can\'t delete yourself.');                  // 8   // 102
                                                                                // 9   // 103
		// remove the user                                                            // 10  // 104
		Meteor.users.remove(userId);                                                  // 11  // 105
	},                                                                             // 12  // 106
                                                                                // 13  // 107
	addUserRole: function(userId, role) {                                          // 14  // 108
		var user = Meteor.user();                                                     // 15  // 109
		if (!user || !Roles.userIsInRole(user, ['admin']))                            // 16  // 110
			throw new Meteor.Error(401, "You need to be an admin to update a user.");    // 17  // 111
                                                                                // 18  // 112
		if (user._id == userId)                                                       // 19  // 113
			throw new Meteor.Error(422, 'You can\'t update yourself.');                  // 20  // 114
                                                                                // 21  // 115
		// handle invalid role                                                        // 22  // 116
		if (Meteor.roles.find({name: role}).count() < 1 )                             // 23  // 117
			throw new Meteor.Error(422, 'Role ' + role + ' does not exist.');            // 24  // 118
                                                                                // 25  // 119
		// handle user already has role                                               // 26  // 120
		if (Roles.userIsInRole(userId, role))                                         // 27  // 121
			throw new Meteor.Error(422, 'Account already has the role ' + role);         // 28  // 122
                                                                                // 29  // 123
		// add the user to the role                                                   // 30  // 124
		Roles.addUsersToRoles(userId, role);                                          // 31  // 125
	},                                                                             // 32  // 126
                                                                                // 33  // 127
	removeUserRole: function(userId, role) {                                       // 34  // 128
		var user = Meteor.user();                                                     // 35  // 129
		if (!user || !Roles.userIsInRole(user, ['admin']))                            // 36  // 130
			throw new Meteor.Error(401, "You need to be an admin to update a user.");    // 37  // 131
                                                                                // 38  // 132
		if (user._id == userId)                                                       // 39  // 133
			throw new Meteor.Error(422, 'You can\'t update yourself.');                  // 40  // 134
                                                                                // 41  // 135
		// handle invalid role                                                        // 42  // 136
		if (Meteor.roles.find({name: role}).count() < 1 )                             // 43  // 137
			throw new Meteor.Error(422, 'Role ' + role + ' does not exist.');            // 44  // 138
                                                                                // 45  // 139
		// handle user already has role                                               // 46  // 140
		if (!Roles.userIsInRole(userId, role))                                        // 47  // 141
			throw new Meteor.Error(422, 'Account does not have the role ' + role);       // 48  // 142
                                                                                // 49  // 143
		Roles.removeUsersFromRoles(userId, role);                                     // 50  // 144
	},                                                                             // 51  // 145
                                                                                // 52  // 146
	addRole: function(role) {                                                      // 53  // 147
		var user = Meteor.user();                                                     // 54  // 148
		if (!user || !Roles.userIsInRole(user, ['admin']))                            // 55  // 149
			throw new Meteor.Error(401, "You need to be an admin to update a user.");    // 56  // 150
                                                                                // 57  // 151
		// handle existing role                                                       // 58  // 152
		if (Meteor.roles.find({name: role}).count() > 0 )                             // 59  // 153
			throw new Meteor.Error(422, 'Role ' + role + ' already exists.');            // 60  // 154
                                                                                // 61  // 155
		Roles.createRole(role);                                                       // 62  // 156
	},                                                                             // 63  // 157
                                                                                // 64  // 158
	removeRole: function(role) {                                                   // 65  // 159
		var user = Meteor.user();                                                     // 66  // 160
		if (!user || !Roles.userIsInRole(user, ['admin']))                            // 67  // 161
			throw new Meteor.Error(401, "You need to be an admin to update a user.");    // 68  // 162
                                                                                // 69  // 163
		// handle non-existing role                                                   // 70  // 164
		if (Meteor.roles.find({name: role}).count() < 1 )                             // 71  // 165
			throw new Meteor.Error(422, 'Role ' + role + ' does not exist.');            // 72  // 166
                                                                                // 73  // 167
		if (role === 'admin')                                                         // 74  // 168
			throw new Meteor.Error(422, 'Cannot delete role admin');                     // 75  // 169
                                                                                // 76  // 170
		// remove the role from all users who currently have the role                 // 77  // 171
		// if successfull remove the role                                             // 78  // 172
		Meteor.users.update(                                                          // 79  // 173
			{roles: role },                                                              // 80  // 174
			{$pull: {roles: role }},                                                     // 81  // 175
			{multi: true},                                                               // 82  // 176
			function(error) {                                                            // 83  // 177
				if (error) {                                                                // 84  // 178
					throw new Meteor.Error(422, error);                                        // 85  // 179
				} else {                                                                    // 86  // 180
					Roles.deleteRole(role);                                                    // 87  // 181
				}                                                                           // 88  // 182
			}                                                                            // 89  // 183
		);                                                                            // 90  // 184
	},                                                                             // 91  // 185
                                                                                // 92  // 186
	updateUserInfo: function(id, property, value) {                                // 93  // 187
		var user = Meteor.user();                                                     // 94  // 188
		if (!user || !Roles.userIsInRole(user, ['admin']))                            // 95  // 189
			throw new Meteor.Error(401, "You need to be an admin to update a user.");    // 96  // 190
                                                                                // 97  // 191
		if (property !== 'profile.name')                                              // 98  // 192
			throw new Meteor.Error(422, "Only 'name' is supported.");                    // 99  // 193
                                                                                // 100
		obj = {};                                                                     // 101
		obj[property] = value;                                                        // 102
		Meteor.users.update({_id: id}, {$set: obj});                                  // 103
                                                                                // 104
	},                                                                             // 105
                                                                                // 106
	addUser: function(name, email, password) {                                     // 107
		var user, userId;                                                             // 108
		user = Accounts.createUser({                                                  // 109
			email: email,                                                                // 110
			profile: {                                                                   // 111
				name: name                                                                  // 112
			}                                                                            // 113
		});                                                                           // 114
		userId = user;                                                                // 115
		Accounts.setPassword(user, password);                                         // 116
		return user;                                                                  // 117
	},                                                                             // 118
                                                                                // 119
	addAdmin: function(email, password, name) {                                    // 120
		if (Meteor.users.findOne({                                                    // 121
			email: email                                                                 // 122
		})) {                                                                         // 123
			return console.log("user already exists");                                   // 124
		} else {                                                                      // 125
			return Meteor.call('addUser', name, email, password, function(err, userId) { // 126
				if (err) {                                                                  // 127
					return console.log(err);                                                   // 128
				} else {                                                                    // 129
					if (Meteor.users.findOne(userId)) {                                        // 130
						Roles.addUsersToRoles(userId, ["admin"]);                                 // 131
						Roles.addUsersToRoles(userId, ["superAdmin"]);                            // 132
					}                                                                          // 133
					if (!Meteor.roles.findOne({                                                // 134
						name: "admin"                                                             // 135
					})) {                                                                      // 136
						return Roles.createRole("admin");                                         // 137
					}                                                                          // 138
				}                                                                           // 139
			});                                                                          // 140
		}                                                                             // 141
	},                                                                             // 142
                                                                                // 143
	impersonate: function(userId, adminUserId) {                                   // 144
		return this._setUserId(userId);                                               // 145
	}                                                                              // 146
                                                                                // 147
});                                                                             // 148
                                                                                // 149
//////////////////////////////////////////////////////////////////////////////////     // 244
                                                                                       // 245
}).call(this);                                                                         // 246
                                                                                       // 247
/////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cfly15:manage-users'] = {
  ManageUsers: ManageUsers
};

})();

//# sourceMappingURL=cfly15_manage-users.js.map
