/* Imports for global scope */

Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
Roles = Package['alanning:roles'].Roles;
ManageUsers = Package['cfly15:manage-users'].ManageUsers;
Accounts = Package['accounts-base'].Accounts;
AccountsServer = Package['accounts-base'].AccountsServer;
HTML = Package.htmljs.HTML;
Iron = Package['iron:core'].Iron;
AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
Log = Package.logging.Log;
Tracker = Package.deps.Tracker;
Deps = Package.deps.Deps;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
_ = Package.underscore._;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
T9n = Package['softwarerero:accounts-t9n'].T9n;

